#include <iostream>
 //#include "Account.h"
#include "date.h"
 using namespace std;

 int main()
 {
 
    Date Fecha{8,3,2022};


 Fecha.displayDate();



 }