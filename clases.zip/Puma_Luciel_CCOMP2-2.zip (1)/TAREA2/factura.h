#include <string>
#include <iostream>

class factura{
    private:
    int Codigo;
    std::string Descripcion;
    int Cantidad;
    int Precio;

    int Impuesto;
    int Descuento;

    public:
    factura( int code,std::string description,int amount,int price,int tax,int discount)
        : Descripcion{description}{}

    void setCodigo(int code) {
        Codigo = code;}
    int getCodigo() const {
        return Codigo ;}


    void setDescripcion(std::string description) {
        Descripcion = description;}
    std::string getDescripcion() const {
        return Descripcion;}


    void setCantidad(int amount) {
        Cantidad = amount;}
    int getCantidad() const {
        return Cantidad ;}


    void setPrecio(int price) {
        Precio = price;}
    int getPrecio() const {
        return Precio ;}


};